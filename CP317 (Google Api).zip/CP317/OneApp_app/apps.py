from django.apps import AppConfig


class OneappAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'OneApp_app'
