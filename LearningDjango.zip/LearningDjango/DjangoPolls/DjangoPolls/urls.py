"""
Definition of urls for DjangoPolls.
"""

from datetime import datetime
from django.urls import path
from django.conf.urls import url, include
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView

import app.forms
import app.views

admin.autodiscover()

urlpatterns = [
    url(r'^', include('app.urls')),
    url(r'^contact$', app.views.contact, name='contact'),
    url(r'^about$', app.views.about, name='about'),
    url(r'^seed$', app.views.seed, name='seed'),
    url(r'^login/$',
        LoginView.as_view,
        {
            'template_name': 'app/login.html',
            'authentication_form': app.forms.BootstrapAuthenticationForm,
            'extra_context':
            {
                'title': 'Log in',
                'year': datetime.now().year,
            }
        },
        name='login'),
    url(r'^logout$',
        LogoutView.as_view,
        {
            'next_page': '/',
        },
        name='logout'),
    path('admin/', admin.site.urls),

    # The admin/doc line below enables admin documentation, which is
    # provided through the docutils library (see requirements.txt).
    url(r'^admin/doc/', include('django.contrib.admindocs.urls')),
]
