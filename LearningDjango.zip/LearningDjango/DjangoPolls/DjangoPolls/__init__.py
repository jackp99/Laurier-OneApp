"""
Package for DjangoPolls.
"""
