from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return render(request, "OneApp_app/home.html")

def about(request):
    return render(request, "OneApp_app/about.html")

def contact(request):
    return render(request, "OneApp_app/contact.html")

def courses(request):
    return render(request, "OneApp_app/courses.html")

def logout(request):
    return render(request, "OneApp_app/logout.html")
    
