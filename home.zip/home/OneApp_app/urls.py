from django.urls import path
from OneApp_app import views 
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),
    path("courses/", views.courses, name="courses"),
    path("logout/", views.logout, name="logout"),
]

urlpatterns += staticfiles_urlpatterns()