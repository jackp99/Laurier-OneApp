from django.shortcuts import render
from django.views.generic import ListView
from django.http import HttpResponse
from django.shortcuts import redirect
from OneApp_app.forms import DocumentForm
from OneApp_app.models import Document
from OneApp_app.forms import QuestionForm
from OneApp_app.models import Question
from OneApp_app.forms import AnswerForm
from OneApp_app.models import Chat
from OneApp_app.forms import ChatForm
from OneApp_app.forms import CoursesForm
from OneApp_app.models import Courses

#Author: Jack Pentesco

class question(ListView):
    model = Question
 
    def get_context_data(self, **kwargs):
        context = super(question, self).get_context_data(**kwargs)
        return context
class chat(ListView):
    model = Chat
 
    def get_context_data(self, **kwargs):
        context = super(chat, self).get_context_data(**kwargs)
        return context

class home(ListView):
    model = Courses
 
    def get_context_data(self, **kwargs):
        context = super(home, self).get_context_data(**kwargs)
        return context

def resources(request):
    return render(request, "OneApp_app/resources.html")

def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():

            newdoc=Document(docfile=request.FILES['docfile'])
            newdoc.save()
            
            return redirect('resources')
    else:
        form = DocumentForm()
    documents=Document.objects.all()
    return render(request, 'OneApp_app/insert_file.html', {'documents':documents,'form': form})

def question_form_upload(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST or None)
        if form.is_valid():

            form.save()
            
            return redirect('questions')
    else:
        form = QuestionForm()
    return render(request, 'OneApp_app/insert_question.html', {'form': form})


def answer_form_upload(request):
    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            
            q=Question.objects.get(id=form.cleaned_data['id'])
            q.answer.insert(0,form.cleaned_data['answer'])
            q.save()
            return redirect('questions')
    else:
        form = AnswerForm()
    return render(request, 'OneApp_app/answer_question.html', {'form': form})


def chat_form_upload(request):
    if request.method == 'POST':
        form = ChatForm(request.POST or None)
        if form.is_valid():

            form.save()
            
            return redirect('chat')
    else:
        form = ChatForm()
    return render(request, 'OneApp_app/insert_chat.html', {'form': form})


def login(request):
    return render(request, "OneApp_app/login.html")

def add_course_form(request):
    form = CoursesForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            course = form.save(commit=False)
            course.save()
            return redirect("home")
    else:
        return render(request, "OneApp_app/add_course.html", {"form": form})