from django import forms
from OneApp_app.models import Document
from OneApp_app.models import Question
from OneApp_app.models import ListField
from OneApp_app.models import Chat


class DocumentForm(forms.Form):
   
    docfile = forms.FileField(
        label='Select a file',
    )
        



class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ('name','question', )

class AnswerForm(forms.Form):
    id=forms.IntegerField(min_value=1)
    answer = forms.CharField(max_length=1000)

class ChatForm(forms.ModelForm):
    class Meta:
        model = Chat
        fields = ('name','message', )

        
        