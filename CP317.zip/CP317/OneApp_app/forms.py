from django import forms
from OneApp_app.models import Document
from OneApp_app.models import Question
from OneApp_app.models import ListField

class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ('name','description', 'document', )

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ('name','question', )

class AnswerForm(forms.Form):
    id=forms.IntegerField()
    answer = forms.CharField(max_length=1000)

        
        