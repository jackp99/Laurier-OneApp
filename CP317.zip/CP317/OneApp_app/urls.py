from django.urls import path
from OneApp_app import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from OneApp_app.models import Document
from OneApp_app.models import Question
from django.conf import settings
from django.conf.urls.static import static
from OneApp_app.models import Chat

question_view = views.question.as_view(
    queryset = Question.objects.order_by("id"),
    context_object_name="questions_list",
    template_name="OneApp_app/questions.html",
)

chat_view = views.chat.as_view(
    queryset = Chat.objects.order_by("uploaded_at"),
    context_object_name="chats_list",
    template_name="OneApp_app/chat.html",
)

urlpatterns = [
    path("", views.resources, name="resources"),
    path("insert_file/", views.model_form_upload, name="insert_file"),
    path("questions/", question_view, name="questions"),
    path("insert_question/", views.question_form_upload, name="insert_question"),
    path("answer_question/", views.answer_form_upload, name="answer_question"),
    path("chat/", chat_view, name="chat"),
    path("insert_chat/", views.chat_form_upload, name="insert_chat"),
    
]

urlpatterns += staticfiles_urlpatterns()